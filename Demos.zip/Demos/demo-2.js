var http = require('http');

var server = http.createServer(function(req,res){

  //path code here

});

server.listen(3000);