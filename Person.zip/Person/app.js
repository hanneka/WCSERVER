var person = require('./Person');

var person1 = new person('James', 'Bond');

console.log(person1.fullName());