var myLogModule = require('./Utility/Log');

myLogModule.info('NodeJS is currently running...');